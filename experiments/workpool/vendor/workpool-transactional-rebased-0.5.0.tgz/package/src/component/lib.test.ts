import { convexTest } from "convex-test";
import {
  afterEach,
  assert,
  beforeEach,
  describe,
  expect,
  it,
  vi,
} from "vitest";
import batchWorker from "@convex-dev/batch-worker/test";
import { api } from "./_generated/api.js";
import type { Id } from "./_generated/dataModel.js";
import schema from "./schema.js";

const modules = import.meta.glob("./**/*.ts");

// Mock Id type
type WorkId = Id<"work">;

describe("lib", () => {
  async function setupTest() {
    const t = convexTest(schema, modules);
    batchWorker.register(t);
    return t;
  }

  let t: Awaited<ReturnType<typeof setupTest>>;

  beforeEach(async () => {
    vi.useFakeTimers();
    t = await setupTest();
  });

  afterEach(() => {
    vi.useRealTimers();
  });

  describe("enqueue", () => {
    it.each([false, true])(
      "rejects transactional actions before enqueueing work (batch: %s)",
      async (batch) => {
        const item = {
          fnHandle: "workHandle",
          fnName: "work",
          fnArgs: { padding: "x".repeat(10_000) },
          fnType: "action" as const,
          runAt: Date.now(),
          completeTransactionally: true,
        };
        await expect(
          batch
            ? t.mutation(api.lib.enqueueBatch, {
                items: [{ ...item, fnType: "mutation" }, item],
                config: {},
              })
            : t.mutation(api.lib.enqueue, { ...item, config: {} }),
        ).rejects.toThrow(
          "completeTransactionally is only supported for mutations and queries",
        );
        await t.run(async (ctx) => {
          expect(await ctx.db.query("work").collect()).toEqual([]);
          expect(await ctx.db.query("pendingStart").collect()).toEqual([]);
          expect(await ctx.db.query("payload").collect()).toEqual([]);
          expect(await ctx.db.query("globals").collect()).toEqual([]);
        });
      },
    );

    it.each([false, true])(
      "accepts legacy, empty, and populated callback exclusions (batch: %s)",
      async (batch) => {
        const callbacks = [
          { fnHandle: "callback", context: { key: "legacy" } },
          { fnHandle: "callback", excludeKinds: [] },
          {
            fnHandle: "callback",
            excludeKinds: ["failed", "canceled"] as const,
          },
        ].map((callback) => ({
          ...callback,
          excludeKinds: callback.excludeKinds && [...callback.excludeKinds],
        }));
        const items = callbacks.map((onComplete) => ({
          fnHandle: "workHandle",
          fnName: "work",
          fnArgs: {},
          fnType: "mutation" as const,
          runAt: Date.now(),
          onComplete,
        }));
        const ids = batch
          ? await t.mutation(api.lib.enqueueBatch, { items, config: {} })
          : await Promise.all(
              items.map((item) =>
                t.mutation(api.lib.enqueue, { ...item, config: {} }),
              ),
            );
        expect(
          await t.run(async (ctx) =>
            Promise.all(
              ids.map(async (id) => (await ctx.db.get("work", id))?.onComplete),
            ),
          ),
        ).toEqual(callbacks);
      },
    );

    it.each([false, true])(
      "rejects invalid status filters before writing any work (batch: %s)",
      async (batch) => {
        const item = {
          fnHandle: "workHandle",
          fnName: "work",
          fnArgs: { payload: "x".repeat(10_000) },
          fnType: "mutation" as const,
          runAt: Date.now(),
        };
        const invalid = {
          ...item,
          onComplete: {
            fnHandle: "callback",
            // @ts-expect-error JavaScript callers can send an invalid kind.
            excludeKinds: ["running"] as ("success" | "failed" | "canceled")[],
          },
        };
        await expect(
          batch
            ? t.mutation(api.lib.enqueueBatch, {
                items: [item, invalid],
                config: {},
              })
            : t.mutation(api.lib.enqueue, { ...invalid, config: {} }),
        ).rejects.toThrow(/Validator error/);
        await t.run(async (ctx) => {
          expect(await ctx.db.query("work").collect()).toEqual([]);
          expect(await ctx.db.query("pendingStart").collect()).toEqual([]);
          expect(await ctx.db.query("payload").collect()).toEqual([]);
          expect(await ctx.db.query("globals").collect()).toEqual([]);
        });
      },
    );

    it("should successfully enqueue a work item", async () => {
      const id = await t.mutation(api.lib.enqueue, {
        fnHandle: "testHandle",
        fnName: "testFunction",
        fnArgs: { test: true },
        fnType: "mutation",
        runAt: Date.now(),
        config: {
          maxParallelism: 10,
          logLevel: "WARN",
        },
      });

      expect(id).toBeDefined();
      const status = await t.query(api.lib.status, { id });
      expect(status).toEqual({ state: "pending", previousAttempts: 0 });
    });

    it("records the queue entry on the work", async () => {
      const id = await t.mutation(api.lib.enqueue, {
        fnHandle: "testHandle",
        fnName: "testFunction",
        fnArgs: {},
        fnType: "mutation",
        runAt: Date.now() + 60_000,
        config: {},
      });
      await t.run(async (ctx) => {
        const pending = await ctx.db.query("pendingStart").unique();
        assert(pending);
        expect((await ctx.db.get("work", id))?.pendingStartId).toBe(
          pending._id,
        );
      });
    });

    it("should throw error if maxParallelism is too high", async () => {
      await expect(
        t.mutation(api.lib.enqueue, {
          fnHandle: "testHandle",
          fnName: "testFunction",
          fnArgs: { test: true },
          fnType: "mutation",
          runAt: Date.now(),
          config: {
            maxParallelism: 500, // More than MAX_POSSIBLE_PARALLELISM
            logLevel: "WARN",
          },
        }),
      ).rejects.toThrow("maxParallelism must be <= 200");
    });

    it("should throw error if maxParallelism is too low", async () => {
      await expect(
        t.mutation(api.lib.enqueue, {
          fnHandle: "testHandle",
          fnName: "testFunction",
          fnArgs: { test: true },
          fnType: "mutation",
          runAt: Date.now(),
          config: {
            maxParallelism: -1, // Less than minimum
            logLevel: "WARN",
          },
        }),
      ).rejects.toThrow("maxParallelism must be >= 0");
    });
  });

  describe("cancel", () => {
    it("should successfully queue a work item for cancelation", async () => {
      const id = await t.mutation(api.lib.enqueue, {
        fnHandle: "testHandle",
        fnName: "testFunction",
        fnArgs: { test: true },
        fnType: "mutation",
        runAt: Date.now(),
        config: {
          maxParallelism: 10,
          logLevel: "WARN",
        },
      });

      await t.mutation(api.lib.cancel, {
        id,
        logLevel: "WARN",
      });

      // Verify a pending cancelation was created
      await t.run(async (ctx) => {
        const pendingCancelations = await ctx.db
          .query("pendingCancelation")
          .collect();
        expect(pendingCancelations).toHaveLength(1);
        expect(pendingCancelations[0].workId).toBe(id);
      });
    });

    it("should not create duplicate cancelation requests", async () => {
      const id = await t.mutation(api.lib.enqueue, {
        fnHandle: "testHandle",
        fnName: "testFunction",
        fnArgs: { test: true },
        fnType: "mutation",
        runAt: Date.now(),
        config: {
          maxParallelism: 10,
          logLevel: "WARN",
        },
      });

      // Cancel the first time
      await t.mutation(api.lib.cancel, {
        id,
        logLevel: "WARN",
      });

      // Cancel the second time
      await t.mutation(api.lib.cancel, {
        id,
        logLevel: "WARN",
      });

      // Verify only one pending cancelation was created
      await t.run(async (ctx) => {
        const pendingCancelations = await ctx.db
          .query("pendingCancelation")
          .collect();
        expect(pendingCancelations).toHaveLength(1);
        expect(pendingCancelations[0].workId).toBe(id);
      });
    });

    it("should not create cancelation for non-existent work", async () => {
      const id = await t.mutation(api.lib.enqueue, {
        fnHandle: "testHandle",
        fnName: "testFunction",
        fnArgs: { test: true },
        fnType: "mutation",
        runAt: Date.now(),
        config: {
          maxParallelism: 10,
          logLevel: "WARN",
        },
      });

      // Delete the work item
      await t.run(async (ctx) => {
        await ctx.db.delete("work", id);
      });

      // Try to cancel the deleted work
      await t.mutation(api.lib.cancel, {
        id,
        logLevel: "WARN",
      });

      // Verify no pending cancelation was created
      await t.run(async (ctx) => {
        const pendingCancelations = await ctx.db
          .query("pendingCancelation")
          .collect();
        expect(pendingCancelations).toHaveLength(0);
      });
    });
  });

  describe("cancelAll", () => {
    it("should queue multiple work items for cancelation", async () => {
      const ids: WorkId[] = [];
      for (let i = 0; i < 3; i++) {
        const id = await t.mutation(api.lib.enqueue, {
          fnHandle: "testHandle",
          fnName: "testFunction",
          fnArgs: { test: i },
          fnType: "mutation",
          runAt: Date.now() + 5 * 60 * 1000,
          config: {
            maxParallelism: 10,
            logLevel: "WARN",
          },
        });
        ids.push(id);
      }

      await t.mutation(api.lib.cancelAll, {
        logLevel: "WARN",
        before: Date.now() + 1000,
      });

      // Verify pending cancelations were created
      await t.run(async (ctx) => {
        const pendingCancelations = await ctx.db
          .query("pendingCancelation")
          .collect();
        expect(pendingCancelations).toHaveLength(3);
        const canceledIds = pendingCancelations.map((pc) => pc.workId);
        expect(canceledIds).toEqual(expect.arrayContaining(ids));
      });
    });

    it("should process work items in batches for cancelAll", async () => {
      const PAGE_SIZE = 64; // Same as in lib.ts

      // Create PAGE_SIZE + 1 work items to trigger pagination
      for (let i = 0; i < PAGE_SIZE + 1; i++) {
        await t.mutation(api.lib.enqueue, {
          fnHandle: "testHandle",
          fnName: "testFunction",
          fnArgs: { test: i },
          fnType: "mutation",
          runAt: Date.now(),
          config: {
            maxParallelism: 10,
            logLevel: "WARN",
          },
        });
      }

      await t.mutation(api.lib.cancelAll, {
        logLevel: "WARN",
        before: Date.now() + 1000,
      });

      // assert that cancelAll was scheduled
      await t.run(async (ctx) => {
        const scheduledFunctions = await ctx.db.system
          .query("_scheduled_functions")
          .collect();
        expect(scheduledFunctions.length).toBeGreaterThan(0);
        // check that one of the scheduled functions is cancelAll
        const cancelAllScheduledFunction = scheduledFunctions.find(
          (sf) => sf.name === "lib:cancelAll",
        );
        expect(cancelAllScheduledFunction).toBeDefined();
        assert(cancelAllScheduledFunction);
      });

      // Verify the first page of cancelations was created
      await t.run(async (ctx) => {
        const pendingCancelations = await ctx.db
          .query("pendingCancelation")
          .collect();

        // We should have at least PAGE_SIZE cancelations
        expect(pendingCancelations.length).toEqual(PAGE_SIZE);
      });
    });
  });

  describe("status", () => {
    it("temporarily reports queued and running legacy work as pending without queue pointers", async () => {
      const { queuedId, runningId } = await t.run(async (ctx) => {
        const work = {
          fnType: "action" as const,
          fnHandle: "testHandle",
          fnName: "testFunction",
          attempts: 0,
        };
        const queuedId = await ctx.db.insert("work", work);
        const runningId = await ctx.db.insert("work", work);
        await ctx.db.insert("pendingStart", {
          workId: queuedId,
          segment: BigInt(Math.floor(Date.now() / 100)),
        });
        return { queuedId, runningId };
      });
      expect(await t.query(api.lib.status, { id: queuedId })).toEqual({
        state: "pending",
        previousAttempts: 0,
      });
      expect(await t.query(api.lib.status, { id: runningId })).toEqual({
        state: "pending",
        previousAttempts: 0,
      });
      expect(
        await t.query(api.lib.statusBatch, { ids: [queuedId, runningId] }),
      ).toEqual([
        { state: "pending", previousAttempts: 0 },
        { state: "pending", previousAttempts: 0 },
      ]);
    });

    it("should return finished state for non-existent work", async () => {
      const id = await t.mutation(api.lib.enqueue, {
        fnHandle: "testHandle",
        fnName: "testFunction",
        fnArgs: { test: true },
        fnType: "mutation",
        runAt: Date.now(),
        config: {
          maxParallelism: 10,
          logLevel: "WARN",
        },
      });
      await t.run(async (ctx) => {
        await ctx.db.delete("work", id);
      });

      const status = await t.query(api.lib.status, { id });
      expect(status).toEqual({ state: "finished" });
    });

    it("should return pending state for newly enqueued work", async () => {
      const id = await t.mutation(api.lib.enqueue, {
        fnHandle: "testHandle",
        fnName: "testFunction",
        fnArgs: { test: true },
        fnType: "mutation",
        runAt: Date.now(),
        config: {
          maxParallelism: 10,
          logLevel: "WARN",
        },
      });

      // Verify work item and pending start were created
      await t.run(async (ctx) => {
        const work = await ctx.db.get("work", id);
        expect(work).toBeDefined();
        const pendingStarts = await ctx.db.query("pendingStart").collect();
        expect(pendingStarts).toHaveLength(1);
        expect(pendingStarts[0].workId).toBe(id);
      });

      const status = await t.query(api.lib.status, { id });
      expect(status).toEqual({ state: "pending", previousAttempts: 0 });
    });

    it("should return running state when work is in progress", async () => {
      const id = await t.mutation(api.lib.enqueue, {
        fnHandle: "testHandle",
        fnName: "testFunction",
        fnArgs: { test: true },
        fnType: "mutation",
        runAt: Date.now(),
        config: {
          maxParallelism: 10,
          logLevel: "WARN",
        },
      });

      // Delete the pendingStart to simulate work in progress
      await t.run(async (ctx) => {
        const pendingStart = await ctx.db.query("pendingStart").first();
        expect(pendingStart).toBeDefined();
        assert(pendingStart);
        await ctx.db.delete("pendingStart", pendingStart._id);
      });

      const status = await t.query(api.lib.status, { id });
      expect(status).toEqual({ state: "running", previousAttempts: 0 });
    });

    it("should return pending state for work pending retry", async () => {
      const id = await t.mutation(api.lib.enqueue, {
        fnHandle: "testHandle",
        fnName: "testFunction",
        fnArgs: { test: true },
        fnType: "mutation",
        runAt: Date.now(),
        retryBehavior: {
          maxAttempts: 3,
          initialBackoffMs: 100,
          base: 2,
        },
        config: {
          maxParallelism: 10,
          logLevel: "WARN",
        },
      });

      // Delete the pendingStart to simulate work in progress
      await t.run(async (ctx) => {
        const pendingStart = await ctx.db.query("pendingStart").first();
        expect(pendingStart).toBeDefined();
        assert(pendingStart);
        await ctx.db.delete("pendingStart", pendingStart._id);

        // Create a pendingCompletion with retry=true to simulate a failed job that will be retried
        await ctx.db.insert("pendingCompletion", {
          workId: id,
          segment: 1n, // Using a simple segment value for testing
          runResult: { kind: "failed", error: "Test error" },
          retry: true,
        });
      });

      const status = await t.query(api.lib.status, { id });
      expect(status).toEqual({ state: "pending", previousAttempts: 0 });
    });

    it("should return running state for work with pendingCancelation", async () => {
      const id = await t.mutation(api.lib.enqueue, {
        fnHandle: "testHandle",
        fnName: "testFunction",
        fnArgs: { test: true },
        fnType: "mutation",
        runAt: Date.now(),
        config: {
          maxParallelism: 10,
          logLevel: "WARN",
        },
      });

      // Delete the pendingStart and add pendingCancelation to simulate cancellation in progress
      await t.run(async (ctx) => {
        const pendingStart = await ctx.db.query("pendingStart").first();
        expect(pendingStart).toBeDefined();
        assert(pendingStart);
        await ctx.db.delete("pendingStart", pendingStart._id);

        // Create a pendingCancelation
        await ctx.db.insert("pendingCancelation", {
          workId: id,
          segment: 1n, // Using a simple segment value for testing
        });
      });

      // According to the implementation, a job with pendingCancelation but no pendingStart
      // or pendingCompletion with retry=true is considered "running"
      const status = await t.query(api.lib.status, { id });
      expect(status).toEqual({ state: "running", previousAttempts: 0 });
    });

    it("should return running state for work with pendingCompletion but retry=false", async () => {
      const id = await t.mutation(api.lib.enqueue, {
        fnHandle: "testHandle",
        fnName: "testFunction",
        fnArgs: { test: true },
        fnType: "mutation",
        runAt: Date.now(),
        config: {
          maxParallelism: 10,
          logLevel: "WARN",
        },
      });

      // Delete the pendingStart and add pendingCompletion with retry=false
      await t.run(async (ctx) => {
        const pendingStart = await ctx.db.query("pendingStart").first();
        expect(pendingStart).toBeDefined();
        assert(pendingStart);
        await ctx.db.delete("pendingStart", pendingStart._id);

        // Create a pendingCompletion with retry=false
        await ctx.db.insert("pendingCompletion", {
          workId: id,
          segment: 1n, // Using a simple segment value for testing
          runResult: { kind: "failed", error: "Test error" },
          retry: false,
        });
      });

      // According to the implementation, a job with pendingCompletion but retry=false
      // is considered "running"
      const status = await t.query(api.lib.status, { id });
      expect(status).toEqual({ state: "running", previousAttempts: 0 });
    });
  });
});
