import { v } from "convex/values";
import type { Doc, Id } from "./_generated/dataModel.js";
import {
  internalMutation,
  internalQuery,
  type MutationCtx,
} from "./_generated/server.js";
import {
  type Config,
  DEFAULT_MAX_PARALLELISM,
  WORKER_NAME,
  toTimestamp,
} from "./shared.js";
import { createLogger, type Logger, logLevel, shouldLog } from "./logging.js";
import { components, internal } from "./_generated/api.js";
import schema from "./schema.js";

/**
 * Record stats about work execution. Intended to be queried by Axiom or Datadog.
 * See the [README](https://github.com/convex/workpool) for example queries.
 */

export function recordEnqueued(
  console: Logger,
  data: {
    workId: Id<"work">;
    fnName: string;
    runAt: number;
  },
) {
  console.event("enqueued", {
    ...data,
    enqueuedAt: Date.now(),
  });
}

export function recordStarted(
  console: Logger,
  work: Doc<"work">,
  lagMs: number,
  scheduledFunctionId: Id<"_scheduled_functions">,
) {
  console.event("started", {
    workId: work._id,
    fnName: work.fnName,
    enqueuedAt: work._creationTime,
    scheduledFunctionId,
    startedAt: Date.now(),
    startLag: lagMs,
  });
}

export function recordCompleted(
  console: Logger,
  work: Doc<"work">,
  status: "success" | "failed" | "canceled" | "retrying",
  onCompleteScheduledFunctionId: Id<"_scheduled_functions"> | undefined,
) {
  console.event("completed", {
    workId: work._id,
    fnName: work.fnName,
    completedAt: Date.now(),
    onCompleteScheduledFunctionId,
    attempts: work.attempts,
    status,
  });
}

export async function generateReport(
  ctx: MutationCtx,
  console: Logger,
  state: Doc<"internalState">,
  { maxParallelism, logLevel }: Config,
) {
  if (!shouldLog(logLevel, "REPORT")) {
    // Don't waste time if we're not going to log.
    return;
  }
  const currentSegment = toTimestamp(Date.now());
  const pendingStart = await ctx.db
    .query("pendingStart")
    .withIndex("segment", (q) =>
      q
        .gte("segment", state.segmentCursors.incoming)
        .lt("segment", currentSegment),
    )
    .paginate({
      numItems: Math.max(maxParallelism, 10),
      cursor: null,
    });
  if (pendingStart.isDone) {
    recordReport(console, {
      ...state.report,
      running: state.running.length,
      backlog: pendingStart.page.length,
    });
  } else {
    await ctx.scheduler.runAfter(0, internal.stats.calculateBacklogAndReport, {
      report: state.report,
      running: state.running.length,
      logLevel,
    });
  }
}

/** Count large backlogs outside the main loop. */
export const calculateBacklogAndReport = internalMutation({
  args: {
    // @deprecated Unused; accepted so in-flight calls from older versions
    // still validate.
    startSegment: v.optional(v.int64()),
    endSegment: v.optional(v.int64()),
    cursor: v.optional(v.string()),
    report: schema.tables.internalState.validator.fields.report,
    running: v.number(),
    logLevel,
  },
  returns: v.null(),
  handler: async (ctx, args) => {
    const console = createLogger(args.logLevel);
    recordReport(console, {
      ...args.report,
      running: args.running,
      backlog: await (ctx.db.query("pendingStart") as any).count(),
    });
    return null;
  },
});

function recordReport(
  console: Logger,
  report: Doc<"internalState">["report"] & { running: number; backlog: number },
) {
  const { completed, failed, retries } = report;
  const withoutRetries = completed - retries;
  const failureRate = completed ? (failed + retries) / completed : 0;
  const permanentFailureRate = withoutRetries ? failed / withoutRetries : 0;
  console.event("report", {
    ...report,
    failureRate: Number(failureRate.toFixed(4)),
    permanentFailureRate: Number(permanentFailureRate.toFixed(4)),
  });
}

/**
 * Returns the currently running work items with summary details.
 * Warning: this should not be used from a mutation, as it will cause conflicts.
 */
export const running = internalQuery({
  args: {},
  returns: v.array(
    v.object({
      workId: v.id("work"),
      scheduledId: v.id("_scheduled_functions"),
      fnName: v.string(),
      started: v.number(),
      attempts: v.number(),
    }),
  ),
  handler: async (ctx) => {
    const internalState = await ctx.db
      .query("internalState")
      .order("desc")
      .first();
    if (!internalState) return [];
    return Promise.all(
      internalState.running.map(async ({ workId, scheduledId, started }) => {
        const work = await ctx.db.get("work", workId);
        return {
          workId,
          scheduledId,
          fnName: work?.fnName ?? "<unknown>",
          started,
          attempts: work?.attempts ?? 0,
        };
      }),
    );
  },
});

/**
 * Warning: this should not be used from a mutation, as it will cause conflicts.
 * Use this while developing to see the state of the queue.
 */
export const diagnostics = internalQuery({
  args: {},
  returns: v.any(),
  handler: async (ctx) => {
    const global = await ctx.db.query("globals").unique();
    const internalState = await ctx.db
      .query("internalState")
      .order("desc")
      .first();
    const inProgressWork = internalState?.running.length ?? 0;
    const maxParallelism = global?.maxParallelism ?? DEFAULT_MAX_PARALLELISM;
    const pendingStart = await (ctx.db.query("pendingStart") as any).count();
    const pendingCompletion = await (
      ctx.db.query("pendingCompletion") as any
    ).count();
    const pendingCancelation = await (
      ctx.db.query("pendingCancelation") as any
    ).count();
    const runStatus = await ctx.runQuery(components.batchWorker.lib.status, {
      name: WORKER_NAME,
    });
    return {
      canceling: pendingCancelation,
      waiting: pendingStart,
      running: inProgressWork - pendingCompletion,
      completing: pendingCompletion,
      spareCapacity: maxParallelism - inProgressWork,
      runStatus: runStatus?.kind,
    };
  },
});

/**
 * Benchmark-only CLI instrumentation for comparing scheduler pressure without
 * expanding the component's public API. Dense ranges can be split by the
 * caller when `overflow` is true.
 */
export const scheduledFunctionsInRange = internalQuery({
  args: {
    startTime: v.number(),
    endTimeExclusive: v.number(),
  },
  returns: v.object({
    count: v.number(),
    overflow: v.boolean(),
  }),
  handler: async (ctx, args) => {
    if (
      !Number.isFinite(args.startTime) ||
      !Number.isFinite(args.endTimeExclusive) ||
      args.endTimeExclusive <= args.startTime ||
      args.endTimeExclusive - args.startTime > 24 * 60 * 60 * 1000
    ) {
      throw new Error("Invalid scheduled-function time range");
    }

    const rows = await ctx.db.system
      .query("_scheduled_functions")
      .withIndex("by_creation_time", (q) =>
        q
          .gte("_creationTime", args.startTime)
          .lt("_creationTime", args.endTimeExclusive),
      )
      .take(1_001);

    return {
      count: Math.min(rows.length, 1_000),
      overflow: rows.length > 1_000,
    };
  },
});
